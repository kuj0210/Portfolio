<!DOCTYPE html>
<html>
	<head>
		<title>수정</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	

	 $dbc = mysqli_connect($host,$user,$pass,$dbname)
		 or die("Error Connecting to MySQL Server.");
		
	$tlt = $_POST['tlt'];
	$poster=$_COOKIE['ID'];
	$query = "select pocketmon.postnum, pocketmon.name, pocketmon.story, pocketmon.poster, IMAGE.imag  from ( pocketmon LEFT  OUTER JOIN IMAGE ON pocketmon.postnum = IMAGE.postnum) where pocketmon.poster = '$poster'";
	$result = mysqli_query($dbc,$query)
			 or die("find pocketmon Error Querying database.");

	while($row = mysqli_fetch_assoc($result)){
		echo '<br/>'.'<article id="work">'	;
			$postnum = $row[postnum];
			$json .="[ $postnum ] "; 
	}						
	
	echo '<form method="post" enctype="multipart/form-data" action="FIX.php">';
		echo'<h1>글 수정하기</h1>';
		echo "<h2>$json"."번호 변경가능합니다.</h2>";	
		echo'고유번호:<br/>';
		echo'<input type="number" name ="dnum"  min="1" style="background-color:#2E2E2E;/"><br/>';
		echo'제목 :<br/>';
		echo'<input type="text" name ="pname" placeholder="제목을 입력해주세요"/><br/>';
		echo'이야기 :<br/>';
		echo'<input type="text" name ="pstory" placeholder="포켓몬 스토리를 짧게 소개해주세요" size="10" style="height:100px";/>';
		echo'<br/>';
		echo'이미지 :<br/>';
		echo'<input type="file" name ="pimage"/><br/>';
		echo'<br/>';
		echo'<input type="submit" value="변경"/>';
	echo'</form>';

	exit('<a href="javascript:history.go(-2)">처음으로.</a>');	
	mysqli_free_result($result);	
	mysqli_close($dbc); 
	
	 
	 
?>
</body>
</html>