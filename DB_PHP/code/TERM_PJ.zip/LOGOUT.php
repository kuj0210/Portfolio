<?php
	session_start();
	ob_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>로그아웃</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (!isset($_SESSION['ID'])){
		exit('<a href="hp.php">로그인 상태가 아닙니다. 홈으로</a>');
	}
	
	$_SESSION = array();
	
	if (isset($_COOKIE[session_name()])){
		setcookie(session_name(), '', time() - (60*60));
	}
	
	session_destroy();
	
	setcookie('id', '', time() - (60*60));
	
	
	echo '로그아웃하였습니다<br/>';
	exit('<a href="hp.php">로그인 상태가 아닙니다. 홈으로</a>');
?>
</body>
</html>