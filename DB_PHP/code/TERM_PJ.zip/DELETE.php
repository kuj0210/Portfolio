<!DOCTYPE html>
<html>
	<head>
		<title>삭제결과</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (empty($_POST['dnum'])) {
		 exit('<a href="javascript:history.go(-1)">삭제할 글의 고유번호를 입력해주세요 .</a>');
	 }
	
	$dbc = mysqli_connect($host,$user,$pass,$dbname)
		 or die("Error Connecting to MySQL Server.");
		
	$num = $_POST['dnum'];
	
	

	
	$deleter = $_COOKIE['ID'];
	$query = "delete from pocketmon where (postnum = $num and poster ='$deleter')";
	$result = mysqli_query($dbc,$query)
			 or die("유효하지 않은 접근입니다.");

	$query = "delete from IMAGE where (postnum = $num and poster ='$deleter')";
	$result = mysqli_query($dbc,$query)
			 or die("intsert pocketmon Error Querying database.");	
	
	
	
	
	exit('<a href="javascript:history.go(-2)">처음으로.</a>');	
	mysqli_free_result($result);	
	mysqli_close($dbc); 
	
	 
	 
?>
</body>
</html>