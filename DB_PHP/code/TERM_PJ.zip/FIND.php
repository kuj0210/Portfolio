<!DOCTYPE html>
<html>
	<head>
		<title>검색결과</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (empty($_POST['tlt'])) {
		 exit('<a href="javascript:history.go(-1)">찾을 글의 제목을 입력해주세요 .</a>');
	 }
	
	 $dbc = mysqli_connect($host,$user,$pass,$dbname)
		 or die("Error Connecting to MySQL Server.");
		
	$tlt = $_POST['tlt'];
	echo $tlt;
	$query = "select pocketmon.postnum, pocketmon.name, pocketmon.story, pocketmon.poster, IMAGE.imag  from ( pocketmon LEFT  OUTER JOIN IMAGE ON pocketmon.postnum = IMAGE.postnum) where pocketmon.name = '$tlt'";
	$result = mysqli_query($dbc,$query)
			 or die("find pocketmon Error Querying database.");
	while($row = mysqli_fetch_assoc($result)){
		echo '<br/>'.'<article id="work">'	;
			$postnum = $row[postnum];
			$name = $row[name];
			$story = $row[story];
			$poster = $row[poster];
			$path = $row[imag];
		
		echo "<"."고유번호 : "."$postnum".">작성자: "."$poster".'</br>';
		echo "<"."제목:             "."$name"."             >".'</br>';
		echo "$story".'</br>';
		echo "<img src ='$path'>"; 
		echo '</br></br>';
		echo '</article>';

	}						

	
	echo "$pname"."검색완료<br/><br/>";
	exit('<a href="javascript:history.go(-2)">처음으로.</a>');	
	mysqli_free_result($result);	
	mysqli_close($dbc); 
	
	 
	 
?>
</body>
</html>