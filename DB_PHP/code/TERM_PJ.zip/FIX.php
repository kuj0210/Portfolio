<!DOCTYPE html>
<html>
	<head>
		<title>수정결과</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (empty($_POST['dnum'])) {
		 exit('<a href="javascript:history.go(-1)">삭제할 글의 고유번호를 입력해주세요 .</a>');
	 }
	 if (empty($_POST['pname'])||empty($_POST['pstory'])) {
		 exit('<a href="javascript:history.go(-1)">이름,내용은 필수입니다 .</a>');
	 }
	
	$dbc = mysqli_connect($host,$user,$pass,$dbname)
		 or die("Error Connecting to MySQL Server.");
	
	$pname = mysqli_real_escape_string($dbc,trim($_POST['pname']));
	$poster =  $_COOKIE['ID'];
	$pstory = mysqli_real_escape_string($dbc,trim($_POST['pstory']));
	$num = $_POST['dnum'];
	

	$query = "UPDATE pocketmon SET name ='$pname' where postnum = $num";
	$result = mysqli_query($dbc,$query)
			or die("fix name Error Querying database.");	
	$query = "UPDATE pocketmon SET story ='$pstory' where postnum = $num";
	$result = mysqli_query($dbc,$query)
			or die("fix story Error Querying database.");	
			
	if(isset($_FILES['pimage'])){
		$imagepath = "./pimages/".uniqid("img").".".pathinfo($_FILES['pimage']['name'],PATHINFO_EXTENSION);
	
		if(!move_uploaded_file($_FILES['pimage']['tmp_name'],$imagepath)){
			exit('<a href="javascript:history.go(-1)">이미지 저장에러 .</a>');
		}	
		$query = "UPDATE IMAGE SET imag ='$imagepath' where postnum = $num";
		$result = mysqli_query($dbc,$query)
		or die("intsert IMGE Error Querying database.");	
	}
	

	exit('<a href="javascript:history.go(-2)">수정완료.</a>');	
	mysqli_free_result($result);	
	mysqli_close($dbc); 
	
	 
	 
?>
</body>
</html>