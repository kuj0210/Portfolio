<?php
	session_start();
	ob_start();
?>

<!DOCTYPE html>
<!--
	Dimension by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>포켓몬 로어</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">

						<div class="content">
							<div class="inner">
								<h1>포켓몬스터</h1>			
								<p>포켓몬들의 로어를 모아두는 곳!</p>
							</div>
						</div>
						<nav>
							<ul>
							<li><a href="#intro">소개</a></li>
							
							<?php
								if(!isset($_SESSION['ID'])){
					
									echo '<li><a href="#LOGIN">로그인</a></li>';
								}
								else{
									echo '<li><a href="#work">도감</a></li>';
									echo '<li><a href="#LOGOUT">로그아웃</a></li>';
								}	
							?>
								
								<li><a href="#contact">회원가입</a></li>
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

				<!-- Main -->
					<div id="main">

						<!-- 소개 -->
							<article id="intro">
								<h2 class="major">Intro</h2>
								<span class="image main"><img src="images/pic01.jpg" alt="" /></span>
								<p>안녕하세요. 저희 게시판을 찾아주셔서 감사합니다. 저희는 각종 포켓몬들의 숨겨진 이야기나 로어들을 공유하는 게시판으로 부족하지만 계속해서 추가해 나갈 예정이니 많은 관심 부탁드립니다.</p>
								<p><br/>약력<p/>
								<p>2017년 3월 게시판 디자인 완료<p/>
								<p>2017년 4월 DB연동 및 각 종 내용 수집<p/>
								<p>2017년 4월 회원가입, 로그인 가능<p/>
								<p>2017년 5월 디자인 변경<p/>
								<p>2017년 6월 ~ 한글패치중 <p/>
							</article>

						<!-- 도감 -->
													
							<article id="work">
								<form method="post" enctype="multipart/form-data" action="POST.php">
								<h1>글쓰기</h1>
									제목 :<br/>
									<input type="text" name ="pname" placeholder="제목을 입력해주세요"/><br/>
									이야기 :<br/>
									<input type="text" name ="pstory" placeholder="포켓몬 스토리를 짧게 소개해주세요" size="10" style="height:100px";/>
									<br/>
									이미지 :<br/>
									<input type="file" name ="pimage"/><br/>
									<br/>
									<input type="submit" value="작성"/>
								</form>
							</article>
							<br/>
							<article id="work">
								<form method="post" enctype="multipart/form-data" action="DELETE.php">	
									<h1>글 지우기</h1>
									고유번호:<br/>
									<input type="number" name ="dnum"  min="1" style="background-color:#2E2E2E;/">
									<input type="submit" value="제거"/><br/>
								</form>
								<form method="post" enctype="multipart/form-data" action="FIND.php">	
									<h1>제목으로 검색</h1>
									제목:<br/>
									<input type="text" name ="tlt" placeholder="제목을 입력해주세요"/>
									<input type="submit" value="찾기"/><br/>
								</form>
								<form method="post" enctype="multipart/form-data" action="FIXFORM.php">	
									<h1>고치기</h1>
									<input type="submit" value="수정하기"/><br/>
								</form>
							</article>	
							<br>
							<article id="work">
							<h1><게시글></h1>
							</article>
							<?php
								require_once('dbcon.php');
								$dbc = mysqli_connect("127.0.0.1","root","apmsetup","PocketMonster")								
									or die("Error Connecting to MySQL Server.");

								$query = "set names euckr";
								$result = mysqli_query($dbc,$query)
									or die("Get pocketmon Error Querying database.");
									
									
								$query = "SELECT pocketmon.postnum, pocketmon.name, pocketmon.story, pocketmon.poster, IMAGE.imag FROM pocketmon LEFT  OUTER JOIN IMAGE ON pocketmon.postnum = IMAGE.postnum";
								$result = mysqli_query($dbc,$query)
									or die("Get pocketmon Error Querying database.");	
									
								while($row = mysqli_fetch_assoc($result)){
								echo '<br/>'.'<article id="work">'	;
									$postnum = $row[postnum];
									$name = $row[name];
									$story = $row[story];
									$poster = $row[poster];
									$path = $row[imag];
									
									echo "<"."고유번호 : "."$postnum".">작성자: "."$poster".'</br>';
									echo "<"."제목:             "."$name"."             >".'</br>';
									echo "$story".'</br>';
									echo "<img src ='$path'>"; 
									echo '</br></br>';
								echo '</article>';

								}	
															
									
								mysqli_free_result($result);	
								mysqli_close($dbc);
								
								?>	
							
						<!-- 로그인 -->
							<article id="LOGIN">
								<h2 class="major">로그인</h2>
								<form method="post" action="LOGIN.php">
									E-mail :<br/>
									<input type="text" name ="ID" placeholder="EMAIL을 입력해주세요"/><br/>
									비밀번호 :<br/>
									<input type="text" name ="PASSWORD" placeholder="비밀번호를 입력해주세요"/><br/>
									<br/><br/>
									<input type="submit" value="로그인"/><br/>
									비밀번호는 일단 암호화 되었지만, 이미 다른곳에서 개인정보가 유출된것은 유감입니다. 걱정하는걸 포기하세요
								</form>
							</article>
						<!-- 로그아웃 -->
							<article id="LOGOUT">
								<h2 class="major">로그아웃</h2>
								<form method="post" action="LOGOUT.php">
									잘생각하셨습니다. sns와 저희사이트는 인생의 낭비입니다 줄이시고 허리쭉펴고 햇볕쬐세요<br/>
									<input type="submit" value="로그아웃"/><br/>
									
								</form>
							</article>

						<!-- 회원가입 -->
							<article id="contact">
								<h2 class="major">회원가입</h2>
								<form method="post" action="Gast.php">
									E-mail :<br/>
									<input type="text" name ="ID" placeholder="ID로 쓸 EMAIL을 입력해주세요"/><br/>
									비밀번호 :<br/>
									<input type="text" name ="PASSWORD" placeholder="비밀번호를 입력해주세요"/><br/>
									<br/><br/>
									<input type="submit" value="회원가입"/><br/>
									이미 해커들은 여러분의 모든 개인정보 다 알고있습니다!. 안심하고 가입하세요!
								</form>
							</article>

						<!-- Elements -->
							<article id="elements">
								<h2 class="major">Elements</h2>

								<section>
									<h3 class="major">Text</h3>
									<p>This is <b>bold</b> and this is <strong>strong</strong>. This is <i>italic</i> and this is <em>emphasized</em>.
									This is <sup>superscript</sup> text and this is <sub>subscript</sub> text.
									This is <u>underlined</u> and this is code: <code>for (;;) { ... }</code>. Finally, <a href="#">this is a link</a>.</p>
									<hr />
									<h2>Heading Level 2</h2>
									<h3>Heading Level 3</h3>
									<h4>Heading Level 4</h4>
									<h5>Heading Level 5</h5>
									<h6>Heading Level 6</h6>
									<hr />
									<h4>Blockquote</h4>
									<blockquote>Fringilla nisl. Donec accumsan interdum nisi, quis tincidunt felis sagittis eget tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan faucibus. Vestibulum ante ipsum primis in faucibus lorem ipsum dolor sit amet nullam adipiscing eu felis.</blockquote>
									<h4>Preformatted</h4>
									<pre><code>i = 0;

while (!deck.isInOrder()) {
    print 'Iteration ' + i;
    deck.shuffle();
    i++;
}

print 'It took ' + i + ' iterations to sort the deck.';</code></pre>
								</section>

								<section>
									<h3 class="major">Lists</h3>

									<h4>Unordered</h4>
									<ul>
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Alternate</h4>
									<ul class="alt">
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Ordered</h4>
									<ol>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis viverra.</li>
										<li>Felis enim feugiat.</li>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis lorem.</li>
										<li>Felis enim et feugiat.</li>
									</ol>
									<h4>Icons</h4>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
										<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
									</ul>

									<h4>Actions</h4>
									<ul class="actions">
										<li><a href="#" class="button special">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions vertical">
										<li><a href="#" class="button special">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Table</h3>
									<h4>Default</h4>
									<div class="table-wrapper">
										<table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>

									<h4>Alternate</h4>
									<div class="table-wrapper">
										<table class="alt">
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>
								</section>

								<section>
									<h3 class="major">Buttons</h3>
									<ul class="actions">
										<li><a href="#" class="button special">Special</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button">Default</a></li>
										<li><a href="#" class="button small">Small</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button special icon fa-download">Icon</a></li>
										<li><a href="#" class="button icon fa-download">Icon</a></li>
									</ul>
									<ul class="actions">
										<li><span class="button special disabled">Disabled</span></li>
										<li><span class="button disabled">Disabled</span></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Form</h3>
									<form method="post" action="#">
										<div class="field half first">
											<label for="demo-name">Name</label>
											<input type="text" name="demo-name" id="demo-name" value="" placeholder="Jane Doe" />
										</div>
										<div class="field half">
											<label for="demo-email">Email</label>
											<input type="email" name="demo-email" id="demo-email" value="" placeholder="jane@untitled.tld" />
										</div>
										<div class="field">
											<label for="demo-category">Category</label>
											<div class="select-wrapper">
												<select name="demo-category" id="demo-category">
													<option value="">-</option>
													<option value="1">Manufacturing</option>
													<option value="1">Shipping</option>
													<option value="1">Administration</option>
													<option value="1">Human Resources</option>
												</select>
											</div>
										</div>
										<div class="field half first">
											<input type="radio" id="demo-priority-low" name="demo-priority" checked>
											<label for="demo-priority-low">Low</label>
										</div>
										<div class="field half">
											<input type="radio" id="demo-priority-high" name="demo-priority">
											<label for="demo-priority-high">High</label>
										</div>
										<div class="field half first">
											<input type="checkbox" id="demo-copy" name="demo-copy">
											<label for="demo-copy">Email me a copy</label>
										</div>
										<div class="field half">
											<input type="checkbox" id="demo-human" name="demo-human" checked>
											<label for="demo-human">Not a robot</label>
										</div>
										<div class="field">
											<label for="demo-message">Message</label>
											<textarea name="demo-message" id="demo-message" placeholder="Enter your message" rows="6"></textarea>
										</div>
										<ul class="actions">
											<li><input type="submit" value="Send Message" class="special" /></li>
											<li><input type="reset" value="Reset" /></li>
										</ul>
									</form>
								</section>

							</article>

					</div>

				<!-- Footer -->
	

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
