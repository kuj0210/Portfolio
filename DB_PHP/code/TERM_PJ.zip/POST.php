<!DOCTYPE html>
<html>
	<head>
		<title>포켓몬 게시글</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (empty($_POST['pname'])||empty($_POST['pstory'])) {
		 exit('<a href="javascript:history.go(-1)">이름,내용은 필수입니다 .</a>');
	 }
	
	$dbc = mysqli_connect($host,$user,$pass,$dbname)
		or die("Error Connecting to MySQL Server.");
		
	$pname = mysqli_real_escape_string($dbc,trim($_POST['pname']));
	$poster =  $_COOKIE['ID'];
	$pstory = mysqli_real_escape_string($dbc,trim($_POST['pstory']));
	
	$query = "insert into pocketmon values (null,'$pname','$pstory','$poster')";
	$result = mysqli_query($dbc,$query)
			or die("intsert pocketmon Error Querying database.");
	mysqli_query($dbc,'set names utf8');
	
	
	if(isset($_FILES['pimage'])){
		$query = "select * from pocketmon";
		$result = mysqli_query($dbc,$query)
			or die("Get pocketmon Error Querying database.");
	
		while($row = mysqli_fetch_assoc($result)){
			$max = $row[postnum];
		}
		mysqli_free_result($result);
		$imagepath = "./pimages/".uniqid("img").".".pathinfo($_FILES['pimage']['name'],PATHINFO_EXTENSION);
	
		if(!move_uploaded_file($_FILES['pimage']['tmp_name'],$imagepath)){
			exit('<a href="javascript:history.go(-1)">이미지 저장에러 .</a>');
		}
		
		$query = "insert into IMAGE values ($max,'$pname','$imagepath','$poster')";
		
		$result = mysqli_query($dbc,$query)
			or die("insert img Error Querying database.");
		mysqli_query($dbc,'set names utf8');
	}
	


	echo "$pname"."게시완료<br/><br/>";
	exit('<a href="javascript:history.go(-2)">처음으로.</a>');	
	mysqli_free_result($result);	
	mysqli_close($dbc); 
	
	 
	 exit('<a href="javascript:history.go(-2)">처음으로.</a>');
?>
</body>
</html>