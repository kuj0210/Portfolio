<!DOCTYPE html>
<html>
<head>
	<head>
		<title>회원가입</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
<body>
<?php
	require_once('dbcon.php');
	
	if (empty($_POST['ID'])||empty($_POST['PASSWORD'])) {
		 exit('<a href="javascript:history.go(-1)">EMAIL주소를 확인해주세요 .</a>');
	 }	
	if (empty($_POST['PASSWORD'])) {
		exit('<a href="javascript:history.go(-1)">비밀번호를 확인해주세요.</a>');
	}
	
	$dbc = mysqli_connect($host,$user,$pass,$dbname)
		or die("Error Connecting to MySQL Server.");
		
	$ID = mysqli_real_escape_string($dbc,trim($_POST['ID']));
	$PASSWORD = mysqli_real_escape_string($dbc,trim($_POST['PASSWORD']));
	$query = "select id from GAST where id='$ID'";
	$result = mysqli_query($dbc,$query)
			or die("Error Querying database.");
	if (mysqli_num_rows($result) != 0) {
	exit('<a href="javascript:history.go(-1)">이미 등록한 EMAIL입니다</a>');
	}
	mysqli_free_result($result);
	
	mysqli_query($dbc,'set names utf8');
	$query = "insert into GAST values ('$ID',SHA('$PASSWORD'))";
	
	$result = mysqli_query($dbc,$query)
			or die("Error Querying database.");
	mysqli_close($dbc); 
	
	echo "$ID"."님! 오늘부터 우리와 함께합니다!<br/><br/>";
	exit('<a href="javascript:history.go(-2)">처음으로.</a>');
?>
</body>
</html>