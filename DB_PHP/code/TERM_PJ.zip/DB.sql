﻿DROP DATABASE  PocketMonster;
create database PocketMonster
	default character set utf8
	default collate utf8_general_ci;
	use PocketMonster;


create table PocketMonster.pocketmon(
	postnum int(11) not null auto_increment,
	name varchar(50),
	story varchar(255),
	poster char(20) default 'admin',
	primary key(postnum)
)ENGINE=InnoDB
default character set utf8
default collate utf8_general_ci;


create table PocketMonster.IMAGE(
	postnum int(11),
	name varchar(50),
	imag varchar(255) default './pimages/dfimage.jpg',
	poster varchar(20),
	primary key(postnum)
)ENGINE=InnoDB
default character set utf8
default collate utf8_general_ci;


create table PocketMonster.GAST(
	id varchar(20),
	pw varchar(255),
	primary key(id)
)ENGINE=InnoDB
default character set utf8
default collate utf8_general_ci;



set names euckr;


insert into PocketMonster.pocketmon 
VALUES(null,'pikachu',"
The hero's partner Pokemon. When first appearing, there is the story of the main character and the brain death state with the lightning.",'admin');

insert into PocketMonster.pocketmon 
VALUES(null,'Paras','An early-emergent herbal medicine pokemon. The mushrooms are dominated by mushrooms and are governed by mushrooms during evolution.','admin');

insert into PocketMonster.pocketmon 
VALUES(null,'Dunkle',"Children's boots, seaweed grown on the body.It reminds me of a child who came back after he died in the sea.",'admin');

insert into PocketMonster.GAST 
VALUES('admin','0000');
insert into PocketMonster.GAST 
VALUES('gast','0001');


select * from PocketMonster.pocketmon;
select * from PocketMonster.GAST;
select * from PocketMonster.IMAGE;





	# SELECT pocketmon.postnum, pocketmon.name, pocketmon.story, pocketmon.poster, IMAGE.imag FROM pocketmon LEFT  OUTER JOIN IMAGE ON pocketmon.postnum = IMAGE.postnum;
	# select pocketmon.postnum, pocketmon.name, pocketmon.story, pocketmon.poster, IMAGE.imag  from ( pocketmon LEFT  OUTER JOIN IMAGE ON pocketmon.postnum = IMAGE.postnum) where pocketmon.poster = "on_11@naver.com";
