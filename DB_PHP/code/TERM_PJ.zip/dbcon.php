<!DOCTYPE html>
<?php
	$host = "127.0.0.1" ;
	$user = "root";
	$pass = "apmsetup";
	$dbname ="PocketMonster";
?>