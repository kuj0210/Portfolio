#pragma once
#include "afxwin.h"
class UBtn :
	public CButton
{
public:
	UBtn(void);
	~UBtn(void);
	DECLARE_MESSAGE_MAP()
	
};

