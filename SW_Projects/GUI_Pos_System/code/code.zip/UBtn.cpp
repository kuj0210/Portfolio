#include "stdafx.h"
#include "UBtn.h"
#include "����3View.h"
#include "MainFrm.h"

UBtn::UBtn(void)
{
}


UBtn::~UBtn(void)
{
}
BEGIN_MESSAGE_MAP(UBtn, CButton)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


