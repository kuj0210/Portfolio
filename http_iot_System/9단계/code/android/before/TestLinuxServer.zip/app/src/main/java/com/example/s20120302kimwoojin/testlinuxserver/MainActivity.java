package com.example.s20120302kimwoojin.testlinuxserver;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;










public class MainActivity extends AppCompatActivity   {
    private  Thread mclient;
    private  Thread mAlam;
    private TextView dataView;
    private TextView infoView;
    public float Temp;
    public float Humi;
    Vibrator vide;

    class AlamThread implements Runnable {
        private StringBuffer TempMessage=null;

        public BufferedInputStream bis=null;
        public BufferedOutputStream bos=null;
        public ServerSocket serverSocket=null;
        public Socket sk;


        public void sendMessage(String message) throws IOException {
            bos.write(message.getBytes());
            bos.flush();
        }
        public String receiveMessage() throws IOException {
            //8192
            byte[] buf = new byte[4096];
            StringBuffer strbuf = new StringBuffer(4096);
            int read = 0;
            while((read = bis.read(buf)) > 0) {
                strbuf.append(new String(buf, 0, read));
            }

            return new String(strbuf);
        }
        void server(){

            try {
                serverSocket = new ServerSocket(9090);
                Log.i("TEST_ALAM", "알람포트 오픈");
                sk=serverSocket.accept();

                Log.i("TEST_ALAM", "알람커넥트완료 오픈");

                bis = new BufferedInputStream(sk.getInputStream());
                bos = new BufferedOutputStream(sk.getOutputStream());
                Log.i("TEST_ALAM", "버퍼류 오픈");
                String Text=this.receiveMessage();
                Log.i("TEST_ALAM", "알람메세지받음");
                infoView.setText(Text);
                bis.close();
                bos.close();
            } catch (Exception e) {
                Log.i("TEST_ALAM", "알람예외");
            }
        }
        @Override
        public void run() {
            this.server();
        }
    }

    class ClientThread implements Runnable {
        private MainActivity mMather=null;
        private StringBuffer TempMessage=null;
        public String TempText;
        public String  completeText;
        public BufferedInputStream bis=null;
        public BufferedOutputStream bos=null;
        public Socket socket=null;
        public static final String SERVER_IP = "192.168.0.108";


        public ClientThread(MainActivity m,TextView data,TextView info) {
            mMather=m;
        }
        public void sendMessage(String message) throws IOException {
            bos.write(message.getBytes());
            bos.flush();
        }
        public String receiveMessage() throws IOException {
            //8192
            byte[] buf = new byte[4096];
            StringBuffer strbuf = new StringBuffer(4096);
            int read = 0;
            while((read = bis.read(buf)) > 0) {
                strbuf.append(new String(buf, 0, read));
            }

            return new String(strbuf);
        }
        void updateTemp(){
            try {
                Log.i("TEST_MSG", "함수진입");
                InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
                Log.i("TEST_MSG", "serverAddr생성완");
                socket = new Socket(serverAddr, 8080);
                Log.i("TEST_MSG", "소켓생성성공");
                bis = new BufferedInputStream(socket.getInputStream());
                bos = new BufferedOutputStream(socket.getOutputStream());
                Log.i("TEST_MSG", "버퍼생성성공");


                TempMessage= new StringBuffer();
                TempMessage.append("GET /dataGet.cgi?name=temperature&N=1 HTTP/1.1\r\n");
                TempMessage.append("\r\n");
                this.sendMessage(new String(TempMessage));
                Log.i("TEST_MSG","보내기성공");
                TempText =this.receiveMessage();
                Log.i("TEST_MSG","받기성공");
                completeText=""+TempText.split("</html>")[1];
                Temp=Float.valueOf(TempText.split("temperature : ")[1]);
                if(Temp>33){
                    Log.i("viv","온도");
                    vide.vibrate(1000);
                }
                bis.close();
                bos.close();
                socket.close();
            } catch (UnknownHostException e1) {
                Log.i("TEST_MSG",e1.toString());
                e1.printStackTrace();
            } catch (IOException e1) {
                Log.i("TEST_MSG",e1.toString());
                e1.printStackTrace();
            } catch(Exception e) {
                Log.i("TEST_MSG", "IO오류");
            }


        }
        void updateHumi(){
            try {
                Log.i("TEST_MSG", "함수진입");
                InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
                Log.i("TEST_MSG", "serverAddr생성완");
                socket = new Socket(serverAddr, 8080);
                Log.i("TEST_MSG", "소켓생성성공");
                bis = new BufferedInputStream(socket.getInputStream());
                bos = new BufferedOutputStream(socket.getOutputStream());
                Log.i("TEST_MSG", "버퍼생성성공");


                TempMessage= new StringBuffer();
                TempMessage.append("GET /dataGet.cgi?name=humidity&N=1 HTTP/1.1\r\n");
                TempMessage.append("\r\n");
                this.sendMessage(new String(TempMessage));
                Log.i("TEST_MSG","보내기성공");
                TempText =this.receiveMessage();
                Log.i("TEST_MSG2",TempText.split("humidity : ")[1]);
                completeText+=TempText.split("</html>")[1];
                Humi=Float.valueOf(TempText.split("humidity : ")[1]);
                completeText="\n<온습도 센서>\n\n"+completeText.split("\n")[2]+"\n"+completeText.split("\n")[7];
                dataView.setText(completeText);


                if(Humi>60){
                    Log.i("viv","습도");
                    vide.vibrate(1000);
                }
                bis.close();
                bos.close();
                socket.close();
            } catch (UnknownHostException e1) {
                Log.i("TEST_MSG",e1.toString());
                e1.printStackTrace();
            } catch (IOException e1) {
                Log.i("TEST_MSG",e1.toString());
                e1.printStackTrace();
            } catch(Exception e) {
                Log.i("TEST_MSG", "IO오류");
            }


        }
        @Override
        public void run(){
            this.updateTemp();
            this.updateHumi();



        }











    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataView=(TextView) findViewById(R.id.data);
        infoView=(TextView)findViewById(R.id.info);
        vide = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        //mAlam= new Thread(new AlamThread() );

        //mAlam.start();


    }
    public void update_View(View v){
        mclient= new Thread(new ClientThread( this,dataView,infoView ) );
        mclient.start();
    }


}