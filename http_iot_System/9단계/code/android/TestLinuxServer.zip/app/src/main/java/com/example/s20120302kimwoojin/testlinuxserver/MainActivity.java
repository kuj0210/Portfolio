package com.example.s20120302kimwoojin.testlinuxserver;

import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {
    private Thread mclient;
    private Thread mAlam;
    private TextView dataView;
    private TextView infoView;
    public float Temp;
    public float Humi;
    Vibrator vide;
    int datasize;
    private ListView humiListView;
    private ListView tempListView;

    ArrayList<String> humiList;
    ArrayList<String> tempList;

    ArrayAdapter<String> humiAdp;
    ArrayAdapter<String> tempAdp;



    class AlamThread implements Runnable {
        private StringBuffer TempMessage = null;

        public BufferedInputStream bis = null;
        public BufferedOutputStream bos = null;
        public ServerSocket serverSocket = null;
        public Socket sk;


        public void sendMessage(String message) throws IOException {
            bos.write(message.getBytes());
            bos.flush();
        }

        public String receiveMessage() throws IOException {
            //8192
            byte[] buf = new byte[4096];
            StringBuffer strbuf = new StringBuffer(4096);
            int read = 0;
            while ((read = bis.read(buf)) > 0) {
                strbuf.append(new String(buf, 0, read));
            }

            return new String(strbuf);
        }

        void server() {

            try {
                serverSocket = new ServerSocket(9090);
                Log.i("TEST_ALAM", "알람포트 오픈");
                sk = serverSocket.accept();

                Log.i("TEST_ALAM", "알람커넥트완료 오픈");

                bis = new BufferedInputStream(sk.getInputStream());
                bos = new BufferedOutputStream(sk.getOutputStream());
                Log.i("TEST_ALAM", "버퍼류 오픈");
                String Text = this.receiveMessage();
                Log.i("TEST_ALAM", "알람메세지받음");
                infoView.setText(Text);
                bis.close();
                bos.close();
            } catch (Exception e) {
                Log.i("TEST_ALAM", "알람예외");
            }
        }

        @Override
        public void run() {
            this.server();
        }
    }
    class ClientThread implements Runnable {
        private StringBuffer TempMessage = null;
        public String TempText;
        public BufferedInputStream bis = null;
        public BufferedOutputStream bos = null;
        public Socket socket = null;
        public static final String SERVER_IP = "192.168.0.108";


        public ClientThread(MainActivity m, TextView data, TextView info) {
        }
        public void sendMessage(String message) throws IOException {
            bos.write(message.getBytes());
            bos.flush();
        }
        public String receiveMessage() throws IOException {
            //8192
            byte[] buf = new byte[4096];
            StringBuffer strbuf = new StringBuffer(4096);
            int read = 0;
            while ((read = bis.read(buf)) > 0) {
                strbuf.append(new String(buf, 0, read));
            }

            return new String(strbuf);
        }

        public void openSocket() {
            try {
                InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
                socket = new Socket(serverAddr, 8080);
                bis = new BufferedInputStream(socket.getInputStream());
                bos = new BufferedOutputStream(socket.getOutputStream());
            } catch (UnknownHostException e1) {
                Log.i("TEST_MSG", e1.toString());
                e1.printStackTrace();
            } catch (IOException e1) {
                Log.i("TEST_MSG", e1.toString());
                e1.printStackTrace();
            } catch (Exception e) {
                Log.i("TEST_MSG", "IO오류");
            }

        }
        public void closeSocket() {
            try {
                bis.close();
                bos.close();
                socket.close();
            } catch (UnknownHostException e1) {
                Log.i("TEST_MSG", e1.toString());
                e1.printStackTrace();
            } catch (IOException e1) {
                Log.i("TEST_MSG", e1.toString());
                e1.printStackTrace();
            } catch (Exception e) {
                Log.i("TEST_MSG", "IO오류");
            }

        }

        void getData(){
            updateTemp();
            updateHumi();
        }
        void updateTemp() {
                try {
                    openSocket();
                    TempMessage = new StringBuffer();
                    TempMessage.append(String.format("GET /dataGet.cgi?name=temperature&N=%d HTTP/1.1\r\n",datasize) );
                    TempMessage.append("\r\n");
                    this.sendMessage(new String(TempMessage));
                    TempText = this.receiveMessage();
                    String data = TempText.split("</html>")[1];
                    StringTokenizer tokens = new StringTokenizer(data);

                    tempList = new ArrayList<String>();
                    String[] txt = data.split("\n");
                    for (int i = 2; i < txt.length; i++) {
                        tempList.add(txt[i]);
                    }
                    closeSocket();

                } catch (Exception e) {
                    Log.i("TEST_MSG", e.toString());
                }

            }
        void updateHumi() {
            try {
                openSocket();
                TempMessage = new StringBuffer();
                TempMessage.append(String.format("GET /dataGet.cgi?name=humidity&N=%d HTTP/1.1\r\n",datasize) );
                TempMessage.append("\r\n");
                this.sendMessage(new String(TempMessage));
                TempText = this.receiveMessage();

                String data = TempText.split("</html>")[1];
                StringTokenizer tokens = new StringTokenizer(data);
                humiList = new ArrayList<String>();
                String[] txt = data.split("\n");
                for (int i = 2; i < txt.length; i++) {
                    humiList.add(txt[i]);
                }

                closeSocket();

            } catch (Exception e) {
                Log.i("TEST_MSG", e.toString());
            }

        }

        @Override
        public void run() {
            getData();

        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        datasize=20;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataView = (TextView) findViewById(R.id.data);
        humiListView = (ListView) findViewById(R.id.humilist);
        tempListView = (ListView) findViewById(R.id.templist);

        
        vide = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        String.
    }

    public void update_View(View v) {
        mclient = new Thread(new ClientThread(this, dataView, infoView));
        mclient.start();
        try{
            mclient.join();
            Log.i("JOIN","완료");
            ArrayAdapter humiAdp = new ArrayAdapter(this, android.R.layout.simple_list_item_1, humiList) ;
            ArrayAdapter tempAdp = new ArrayAdapter(this, android.R.layout.simple_list_item_1, tempList) ;
            Log.i("JOIN","어댑터생성");
            humiListView.setAdapter(humiAdp );
            Log.i("JOIN","습도뷰적용");
            tempListView.setAdapter(tempAdp );
            Log.i("JOIN","온도뷰적용");
            dataView.setText(tempList.get(0)+"\n"+humiList.get(0));

        }catch (Exception e){
            Log.i("JOIN ERR",e.toString());
        }
    }










}