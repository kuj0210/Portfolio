#include "stems.h"
#include <sys/time.h>
#include <assert.h>
#include <unistd.h>
#include "Mysql.h"


char *datacut(char *data);
char *timecut(char *data);


//
// This program is intended to help you test your web server.
// 

int main(int argc, char *argv[])
{
	
	int db_temp = db_init();
	char *buf[100];
	char Query[100];
	char *name;
	char *time;
	char *value_name;
	float value;

	char *astr = "Currently, CGI program is running, but argument passing is not implemented.";
 
	int len = atoi(getenv("CONTENT_LENGTH"));
	char* method = getenv("REQUEST_METHOD");
	astr = getenv("QUERY_STRING");
	strcpy(buf, astr);

	//parse
	name = strtok(astr, "&");
	time = strtok(NULL, "&");
	value_name = strtok(NULL, " ");
	

	name = datacut(name);
	time = timecut(time);
	value_name = datacut(value_name);
	//value = atof(value_name);

	sprintf(Query, "INSERT into %s values('%s', '%f', NULL);", name, time, atof(value_name));
	Mysql_query(connect_db,Query);
	update_SensorList(name);

	printf("Method: %s\r\n",method);
	printf("HTTP/1.0 200 OK\r\n");
	printf("Server: My Web Server\r\n");
	printf("Content-Length: %d\r\n", len);
	printf("Content-Type: text/plain\r\n\r\n");
	//printf("datapist strlen(astr) : %ld\n", strlen(astr));
	printf("%s\n",buf);


	fflush(stdout);
	return(0);
}


char *datacut(char *data){
	strtok(data,"=");
	return strtok(NULL," ");
}

char *timecut(char *data)
{
	strtok(data,"=");
	strtok(NULL," ");
	strtok(NULL," ");
	strtok(NULL," ");
	return strtok(NULL," ");
}
