#include "stems.h"
#include <sys/time.h>
#include <assert.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	printf("WARRING : %s\n",getenv(argv[1]));

	fflush(stdout);
	return(0);
}
